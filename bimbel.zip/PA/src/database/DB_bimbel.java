/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package database;
import java.sql.*;

/**
 *
 * @author Asus Notebook
 */
public class DB_bimbel implements specs{
    private final static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String DB_URL = "jdbc:mysql://localhost/bimbel";
    private final String USER = "root";
    private final String PASS = "";

    private Connection conn;
    private Statement stmt;
    protected ResultSet value;
    private String query;

    public DB_bimbel() throws ClassNotFoundException, SQLException {
     Class.forName(JDBC_DRIVER);
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
        stmt = conn.createStatement();}
    
     @Override
    public void setQuery(String sql) {
        this.query = sql;
    }
     @Override
     public String getQuery() {
        return this.query;
     }
     public void execute() throws SQLException {
        stmt.execute(this.query);
    }

    public void fetch() throws SQLException {
        this.value = stmt.executeQuery(this.query);
    }
}
