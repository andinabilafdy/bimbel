/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package remote;
import java.sql.*;
import database.*;
/**
 *
 * @author Asus Notebook
 */
public class remote_akun extends DB_bimbel {

    public remote_akun() throws ClassNotFoundException, SQLException {
        super();
    }
    
    public boolean authentication(String username, String password) throws SQLException {

        String sql = String.format("SELECT * FROM user WHERE username = '%s' AND password = '%s'", username, password);
        this.setQuery(sql);
        this.fetch();

        while(this.value.next()) {
            if(this.value.getString("username") != null) {
                return true;
            }
        }
        
        
        return false;
    }
    
}
    
