/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package remote;
import database.*;
import java.sql.SQLException;
/**
 *
 * @author Asus Notebook
 */
public class Mapel extends DB_bimbel{

    public Mapel() throws ClassNotFoundException, SQLException {
    super();
    }
     
    public void getAll() throws SQLException {
        String sql = "SELECT * FROM mapel";
        this.setQuery(sql);
        this.fetch();
    }
    
    public String[][] showMapel() throws SQLException {
        String[][] data = new String[this.lenMapel()][3];
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            data[i][0] = this.value.getString("Mata_Pelajaran");
            data[i][1] = this.value.getString("Pengajar");
            data[i][2] = this.value.getString("Hari");
            i++;
        }
        return data;
    }
    
    public int lenMapel() throws SQLException {
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            i++;
        }
        return i;
    }
}
