/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package remote;
import database.*;
import java.sql.SQLException;
/**
 *
 * @author Asus Notebook
 */
public class Remote_siswa extends DB_bimbel {

    public Remote_siswa() throws ClassNotFoundException, SQLException {
        super();
    }
    
     public void insertSiswa(String nama, String kelas, String alamat) throws SQLException {
        String tmb = String.format("ALTER TABLE data_siswa AUTO_INCREMENT = 0;");
        String sql = String.format("INSERT INTO data_siswa (nama_siswa,kelas,alamat) VALUE ('%s', '%s','%s')", nama, kelas,
                alamat);
        this.setQuery(tmb);
        this.setQuery(sql);
        this.execute();
    }
    // Read
    public void getAll() throws SQLException {
        String sql = "SELECT * FROM data_siswa";
        this.setQuery(sql);
        this.fetch();
    }
    
    // Update
    public void updateSiswa(int id, String nama, String kelas, String alamat) throws SQLException {
        String sql = String.format("UPDATE data_siswa SET  nama_siswa = '%s', kelas ='%s', alamat ='%s' WHERE id = %d",
                nama, kelas, alamat,id);
        this.setQuery(sql);
        this.execute();
    }

    // Delete
    public void deleteSiswa(int id) throws SQLException {
        String sql = String.format("DELETE FROM data_siswa WHERE id = %d", id);
        this.setQuery(sql);
        this.execute();
    }
    public boolean checkSiswa(String nama) throws SQLException {
        getAll();
        while (this.value.next()) {
            if (this.value.getString("nama_siswa").equals(nama)) {
                return true;
            }
        }
        return false;
    }
    
     // Print siswa
    public String[][] showSiswa() throws SQLException {
        String[][] data = new String[this.lenSiswa()][4];
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            data[i][0] =  Integer.toString(this.value.getInt("id"));
            data[i][1] = this.value.getString("nama_siswa");
            data[i][2] = this.value.getString("kelas");
            data[i][3] = this.value.getString("alamat");
            i++;
        }
        return data;
    }
    
    public int lenSiswa() throws SQLException {
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            i++;
        }
        return i;
    }
}
